CREATE DATABASE  IF NOT EXISTS `twt-virt-office` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `twt-virt-office`;
-- MySQL dump 10.13  Distrib 5.5.34, for debian-linux-gnu (i686)
--
-- Host: 192.168.0.205    Database: twt-virt-office
-- ------------------------------------------------------
-- Server version	5.5.31-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role` char(13) NOT NULL DEFAULT 'user',
  `email` tinytext NOT NULL,
  `salt` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `name` tinytext NOT NULL,
  `surname` tinytext NOT NULL,
  `phone` tinytext,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `create_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `create_user_id` (`create_user_id`),
  KEY `role` (`role`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`create_user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'company_admin','asdasd@asdasd.ru','3a464f90bc5589477014918771d86011','f687752eb2ac46251d375f4a6d5ebed7','asd','asdasd','5465465487978',1,NULL),(2,'user','asdasdasd@asdasd.ru','cf7438e8150468c189a37d80e4ae820f','790b037150265dbf8ab6075000438b13','asdasdasd','234234234','234234',1,NULL),(3,'company_admin','asdfsdfs@asdasd.ru','21a511ae917c30b07d1d151e1916f1ff','d44261376ac8a9695fe8b292a036cf13','asdasdq','weqwe132a','qweqw1423123',1,NULL),(4,'user','dfgdfg@asdasd.ru','d4f239f9af5ba32d06058df8c2cd3254','0a28d14bf7f57516ce11797d36550045','dfgdfg','dfgdfg','asdasdasd',1,NULL),(5,'company_admin','user1@example.com','bb7ecdb275dcb74434bbc2ef7d3a94e8','d7be18247b2f8eb1f5f268f305d06bf9','admin','company','1hhh',1,NULL),(6,'user','deleteme@now.u','16afca464796027f57df3e7aa4461174','e33b83fe0b6c49fbf515658e85cc4ee5','delete','me','1151551',1,NULL),(10,'user','test@test.test','a98f48609bdf0f4117a5a65041f5b6cc','8c9b412cbbf20fa3a0f9ba65cb8a75f9','test','user','lbjadbgaldablni',1,NULL),(16,'user','testuser@aa.aa','745265508d235a8c09e80058071b46bc','3bccbf3fce2b69a1713d0ef5036910ca','aaa','aa','22222222222222',1,NULL),(18,'administrator','admin@ioffice-on.com','3a0322546d7b18c4e37f34f61667779a','9e35259b7d3b9775914615bb6c0be51d','Admin','TWT',NULL,1,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-11-15 17:28:43
