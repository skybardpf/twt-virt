CREATE DATABASE  IF NOT EXISTS `twt-virt-office` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `twt-virt-office`;
-- MySQL dump 10.13  Distrib 5.5.34, for debian-linux-gnu (i686)
--
-- Host: 192.168.0.205    Database: twt-virt-office
-- ------------------------------------------------------
-- Server version	5.5.31-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cbank_account`
--

DROP TABLE IF EXISTS `cbank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cbank_account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `resident` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `account_number` tinytext NOT NULL,
  `bank` tinytext NOT NULL,
  `swift` tinytext,
  `iban` tinytext,
  `bik` tinytext,
  `correspondent` tinytext,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `cbank_account_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cbank_account`
--

LOCK TABLES `cbank_account` WRITE;
/*!40000 ALTER TABLE `cbank_account` DISABLE KEYS */;
INSERT INTO `cbank_account` VALUES (1,2,0,'154575374456768757','Raiffeisen Bank','DJEU45786','4564654 54df78  5','bik1','corr1'),(2,2,1,'acc_num2','bank2','swift2','iban2','bik2','corr2'),(6,2,0,'new','new_bank','new_swift','new_iban',NULL,NULL),(7,2,0,'5','5','5','5',NULL,NULL),(11,2,1,'ddds','adwsd','qr3rq','afwsfw',NULL,NULL),(15,1,1,'erqwq67555','3q2467','241421','21242','67','67'),(16,1,0,'f','f',NULL,NULL,NULL,NULL),(17,1,0,'ytryuy','trtretrer',NULL,NULL,NULL,NULL),(18,1,0,'fdfdfsd','fdsfdfdf',NULL,NULL,NULL,NULL),(20,1,0,'a','a','a','a',NULL,NULL),(21,1,0,'b','b','b','b',NULL,NULL),(22,1,1,'ff','ff','ff','ff',NULL,NULL),(23,1,0,'151654654687654654','Дойче Банк','пвап','впвап',NULL,NULL),(24,1,1,'546666','rerfegtg','gfgfdgh','fgfdgfgd','6yuuy','yuyu'),(25,1,1,'yy','yy',NULL,NULL,'yy','yy'),(26,1,0,'y','y','y','y',NULL,NULL),(27,2,1,'new','new',NULL,NULL,'111','111'),(28,2,1,'6','6',NULL,NULL,'6','6'),(29,9,0,'33','33','33','33',NULL,NULL),(37,25,1,'222346','22346',NULL,NULL,'22346','22346'),(38,25,1,'4456','4456',NULL,NULL,'4456','4456'),(39,25,1,'6','6',NULL,NULL,'656','6'),(40,25,1,'76','76',NULL,NULL,'76','76'),(41,25,1,'77','77',NULL,NULL,'77','77');
/*!40000 ALTER TABLE `cbank_account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-11-15 17:28:44
